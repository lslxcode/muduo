//author voidccc
#ifndef DECLEAR_H
#define DECLEAR_H

class IChannelCallback;
class IAcceptorCallback;
class Channel;
class Acceptor;
class TcpConnection;
class EventLoop;
class Epoll;
class IMuduoUser;
class Buffer;
class TimerQueue;
class Timestamp;
class IRun0;
class IRun2;
class Timer;
class Task;
class Thread;
class ThreadPool;

#endif
