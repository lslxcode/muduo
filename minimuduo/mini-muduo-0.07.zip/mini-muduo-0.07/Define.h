//author voidccc
#ifndef DEFINE_H
#define DEFINE_H

#define MAX_LINE 100
#define MAX_EVENTS 500
#define MAX_LISTENFD 5

#endif
