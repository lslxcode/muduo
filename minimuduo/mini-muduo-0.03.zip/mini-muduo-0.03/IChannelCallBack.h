
class IChannelCallBack
{
    public:
        void virtual OnIn(int sockfd){};
};
