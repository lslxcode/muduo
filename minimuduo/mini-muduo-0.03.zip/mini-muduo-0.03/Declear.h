//author voidccc
#ifndef DECLEAR_H
#define DECLEAR_H

class IChannelCallBack;
class Channel;

#endif
