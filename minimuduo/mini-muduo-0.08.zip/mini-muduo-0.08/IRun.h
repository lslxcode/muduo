//author voidccc
#ifndef IRUN_H
#define IRUN_H

class IRun
{
    public:
        void virtual run() = 0;
};

#endif
