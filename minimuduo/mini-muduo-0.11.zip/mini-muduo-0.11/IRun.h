//author voidccc
#ifndef IRUN_H
#define IRUN_H

class IRun
{
    public:
        void virtual run(void* param) = 0;
};

#endif
