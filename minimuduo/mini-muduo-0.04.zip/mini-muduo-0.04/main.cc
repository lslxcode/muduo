//author voidccc
#include "TcpServer.h"

int main(int args, char** argv)
{
    TcpServer tcpserver;
    tcpserver.start();
    return 0;
}
