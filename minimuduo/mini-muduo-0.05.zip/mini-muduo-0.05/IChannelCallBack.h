//author voidccc
#ifndef ICHANNELCALLBACK_H
#define ICHANNELCALLBACK_H

class IChannelCallBack
{
    public:
        void virtual OnIn(int sockfd){};
};

#endif
