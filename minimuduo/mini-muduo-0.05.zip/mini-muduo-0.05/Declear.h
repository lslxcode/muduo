//author voidccc
#ifndef DECLEAR_H
#define DECLEAR_H

class IChannelCallBack;
class IAcceptorCallBack;
class Channel;
class Acceptor;
class TcpConnection;
class EventLoop;
class Epoll;

#endif
